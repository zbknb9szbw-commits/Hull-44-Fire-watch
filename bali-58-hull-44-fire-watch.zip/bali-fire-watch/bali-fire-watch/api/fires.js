// Vercel serverless function. Requires FIRMS_MAP_KEY in Project Environment Variables.
export default async function handler(req,res){
  const key=process.env.FIRMS_MAP_KEY || 'e4cd08a894fb2f95a6b7d16c5b3c2aad';
  const lat=Number(req.query.lat||42.703333), lon=Number(req.query.lon||3.043333), radius=Math.min(150,Math.max(10,Number(req.query.radius||50)));
  const dLat=radius/111, dLon=radius/(111*Math.cos(lat*Math.PI/180));
  const bbox=[lon-dLon,lat-dLat,lon+dLon,lat+dLat].map(x=>x.toFixed(5)).join(',');
  // VIIRS NOAA-20 NRT, 2-day lookback; newer detections can replace older ones as FIRMS processing advances.
  const url=`https://firms.modaps.eosdis.nasa.gov/api/area/csv/${key}/VIIRS_NOAA20_NRT/${bbox}/2`;
  try{
    const r=await fetch(url,{headers:{'User-Agent':'BaliFireWatch/1.0'}}); if(!r.ok) throw new Error(`FIRMS ${r.status}`); const text=await r.text();
    const rows=parseCSV(text); const fires=rows.filter(x=>x.latitude&&x.longitude);
    res.setHeader('Cache-Control','s-maxage=120, stale-while-revalidate=240'); return res.status(200).json({source:'NASA FIRMS VIIRS NOAA-20 NRT',bbox,fires,generated_at:new Date().toISOString()});
  }catch(e){return res.status(502).json({error:e.message});}
}
function parseCSV(s){const lines=s.trim().split(/\r?\n/);if(lines.length<2)return[];const h=split(lines[0]);return lines.slice(1).filter(Boolean).map(line=>{const v=split(line),o={};h.forEach((k,i)=>o[k]=v[i]??'');return o;});}
function split(line){let out=[],cur='',q=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(q&&line[i+1]==='"'){cur+='"';i++;}else q=!q;}else if(c===','&&!q){out.push(cur);cur='';}else cur+=c;}out.push(cur);return out;}
