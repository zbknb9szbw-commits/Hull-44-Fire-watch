# Bali 5.8 Hull 44 Fire Watch

A mobile-first installable web app centered on Catana/Bali's Canet-en-Roussillon port technical zone.

## What it does
- Live map centered on the Canet factory/port technical zone.
- NASA FIRMS VIIRS near-real-time detections through a serverless proxy.
- 10 / 25 / 50 km distance rings.
- Nearest-fire distance and simple proximity severity.
- Browser notification when a returned detection is within 25 km while the app is active.
- Optional Copernicus EFFIS WMS overlay plus direct authoritative-source links.
- Refreshes every 5 minutes while open.

## Deploy on Vercel
The NASA FIRMS key you supplied is already wired into the server-side function as a fallback, so no additional NASA setup is required for this copy.

1. Deploy this folder to Vercel (direct upload/CLI is preferable to a public GitHub repository).
2. Open the HTTPS site on iPhone Safari > Share > Add to Home Screen.
3. For best security, after deployment add `FIRMS_MAP_KEY` in Vercel Project > Settings > Environment Variables, then remove the fallback key from `api/fires.js`.

Do not publish this source repository publicly while the fallback key remains embedded.

## Important
"Live" means the app checks frequently; the underlying satellite feed is near-real-time, not continuous ground-truth telemetry. NASA FIRMS and EFFIS can have acquisition/processing latency and satellite hotspots can include thermal anomalies. For evacuation or safety decisions use French civil protection, prefecture/fire-brigade notices, and local authorities.

## Monitoring center
Hull: Bali 5.8 Hull 44.

Approximate port center: 42.703333 N, 3.043333 E. Catana Group lists its Canet site at Zone Technique du Port, 66140 Canet-en-Roussillon. Adjust `FACTORY` in index.html if you have the exact building/hull coordinates.
